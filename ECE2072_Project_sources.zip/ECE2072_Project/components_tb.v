`timescale 1ns/1ns
/*
Monash University ECE2072: Assignment
Testbench for the Task 1 components in components.v

Student A: <NAME>, <STUDENT ID>
Student B: <NAME>, <STUDENT ID>
(Each test group below is marked with the student responsible for it.)

Compile in ModelSim: components.v, components_tb.v
Simulate components_tb, then: run -all

Method
  - sign_extend : EXHAUSTIVE - all 512 inputs compared with Verilog's own
                  signed extension.
  - tick_FSM    : reset value, full one-hot sequence, wrap-around, hold when
                  enable = 0, reset in the middle of the sequence.
  - multiplexer : every select value 0-9 with a different value on each input,
                  plus the unused select values 10-15 (must give 0).
  - ALU         : directed edge cases for each operation (signs, zero,
                  overflow, shift by 0 / positive / negative amounts) plus
                  200 random vectors checked against a reference model.
  - register_n  : 16-bit and 9-bit instances: reset, load, hold, reset has
                  priority over load.
Every failure prints the inputs, the actual and the expected value.
A per-component and overall summary is printed at the end.
*/
module components_tb;

	// ---------------- counters ----------------
	integer pass_count = 0, fail_count = 0;
	integer comp_pass, comp_fail;
	integer i, seed;

	task result;
		input ok;
		input [8*70:1] msg;
	begin
		if (ok) begin
			pass_count = pass_count + 1;
			comp_pass  = comp_pass + 1;
		end
		else begin
			fail_count = fail_count + 1;
			comp_fail  = comp_fail + 1;
			$display("   FAIL: %0s", msg);
		end
	end
	endtask

	task begin_component;
		input [8*30:1] name;
	begin
		comp_pass = 0;
		comp_fail = 0;
		$display("------------------------------------------------");
		$display("Testing %0s", name);
	end
	endtask

	task end_component;
		input [8*30:1] name;
	begin
		if (comp_fail == 0)
			$display("%0s: PASSED all %0d checks", name, comp_pass);
		else
			$display("%0s: FAILED %0d of %0d checks", name, comp_fail, comp_pass + comp_fail);
	end
	endtask

	// ---------------- clock for sequential parts ----------------
	reg clk = 1'b0;
	always #5 clk = ~clk;

	// ---------------- sign_extend ----------------
	reg  [8:0]  se_in;
	wire [15:0] se_out;
	sign_extend dut_se(.in(se_in), .ext(se_out));

	// ---------------- tick_FSM ----------------
	reg        fsm_rst, fsm_en;
	wire [3:0] tick;
	tick_FSM dut_fsm(.rst(fsm_rst), .clk(clk), .enable(fsm_en), .tick(tick));

	// ---------------- multiplexer ----------------
	reg  [15:0] m_r0, m_r1, m_r2, m_r3, m_r4, m_r5, m_r6, m_r7, m_g;
	reg  [8:0]  m_din;
	reg  [3:0]  m_sel;
	wire [15:0] m_bus;
	multiplexer dut_mux(.SignExtDin(m_din), .R0(m_r0), .R1(m_r1), .R2(m_r2), .R3(m_r3),
	                    .R4(m_r4), .R5(m_r5), .R6(m_r6), .R7(m_r7), .G(m_g),
	                    .sel(m_sel), .Bus(m_bus));

	// ---------------- ALU ----------------
	reg  [15:0] a, b;
	reg  [2:0]  op;
	wire [15:0] alu_out;
	ALU dut_alu(.input_a(a), .input_b(b), .alu_op(op), .result(alu_out));

	// Reference model for ALU ops 000-011
	function [15:0] alu_model;
		input [15:0] ia, ib;
		input [2:0]  o;
	begin
		case (o)
			3'b000: alu_model = ia * ib;
			3'b001: alu_model = ia + ib;
			3'b010: alu_model = ia - ib;
			3'b011: if ($signed(ia) >= 0) alu_model = ib << ia;
			        else                  alu_model = $signed(ib) >>> (-$signed(ia));
			default: alu_model = 16'd0;
		endcase
	end
	endfunction

	task check_alu;
		input [15:0] ia, ib;
		input [2:0]  o;
		input [15:0] expected;
	begin
		a = ia; b = ib; op = o;
		#1;
		if (alu_out !== expected)
			$display("   ALU op=%b a=%0d b=%0d -> %0d, expected %0d",
				o, $signed(ia), $signed(ib), $signed(alu_out), $signed(expected));
		result(alu_out === expected, "ALU result (see line above)");
	end
	endtask

	// ---------------- register_n ----------------
	reg         r_rst, r_in16, r_in9;
	reg  [15:0] r_d16;
	reg  [8:0]  r_d9;
	wire [15:0] r_q16;
	wire [8:0]  r_q9;
	register_n #(.N(16)) dut_r16(.data_in(r_d16), .r_in(r_in16), .clk(clk), .Q(r_q16), .rst(r_rst));
	register_n #(.N(9))  dut_r9 (.data_in(r_d9),  .r_in(r_in9),  .clk(clk), .Q(r_q9),  .rst(r_rst));

	// ==============================================================
	initial begin
		seed = 2072;
		fsm_rst = 1'b0; fsm_en = 1'b0;
		r_rst = 1'b0; r_in16 = 1'b0; r_in9 = 1'b0; r_d16 = 16'd0; r_d9 = 9'd0;

		$display("================================================");
		$display(" ECE2072 Task 1 - components testbench");
		$display("================================================");

		// ---------- sign_extend (Student A) ----------
		begin_component("sign_extend");
		for (i = 0; i < 512; i = i + 1) begin
			se_in = i;
			#1;
			if (se_out !== {{7{se_in[8]}}, se_in})
				$display("   in=%b out=%b expected=%b", se_in, se_out, {{7{se_in[8]}}, se_in});
			result(se_out === {{7{se_in[8]}}, se_in}, "sign_extend output (see line above)");
		end
		end_component("sign_extend");

		// ---------- tick_FSM (Student A) ----------
		begin_component("tick_FSM");
		@(negedge clk); fsm_rst = 1'b1; fsm_en = 1'b1;
		@(negedge clk); fsm_rst = 1'b0;
		result(tick === 4'b0001, "after reset tick should be 0001");
		@(negedge clk); result(tick === 4'b0010, "tick 1 -> 2 (expected 0010)");
		@(negedge clk); result(tick === 4'b0100, "tick 2 -> 3 (expected 0100)");
		@(negedge clk); result(tick === 4'b1000, "tick 3 -> 4 (expected 1000)");
		@(negedge clk); result(tick === 4'b0001, "tick 4 -> 1 wrap-around (expected 0001)");
		@(negedge clk); result(tick === 4'b0010, "second cycle starts (expected 0010)");
		fsm_en = 1'b0;
		@(negedge clk); result(tick === 4'b0010, "enable = 0 holds state (expected 0010)");
		@(negedge clk); result(tick === 4'b0010, "enable = 0 still holds (expected 0010)");
		fsm_en = 1'b1;
		@(negedge clk); result(tick === 4'b0100, "enable = 1 resumes (expected 0100)");
		fsm_rst = 1'b1;
		@(negedge clk); result(tick === 4'b0001, "reset mid-sequence (expected 0001)");
		fsm_rst = 1'b0; fsm_en = 1'b0;
		@(negedge clk); result(tick === 4'b0001, "reset + enable = 0 stays at 0001");
		end_component("tick_FSM");

		// ---------- multiplexer (Student B) ----------
		begin_component("multiplexer");
		m_r0 = 16'd100; m_r1 = 16'd101; m_r2 = 16'd102; m_r3 = 16'd103;
		m_r4 = 16'd104; m_r5 = 16'd105; m_r6 = 16'd106; m_r7 = 16'd107;
		m_g  = 16'hBEEF; m_din = -9'sd5;                // sign-extends to 0xFFFB
		m_sel = 4'd0; #1; result(m_bus === m_r0, "sel 0 should select R0");
		m_sel = 4'd1; #1; result(m_bus === m_r1, "sel 1 should select R1");
		m_sel = 4'd2; #1; result(m_bus === m_r2, "sel 2 should select R2");
		m_sel = 4'd3; #1; result(m_bus === m_r3, "sel 3 should select R3");
		m_sel = 4'd4; #1; result(m_bus === m_r4, "sel 4 should select R4");
		m_sel = 4'd5; #1; result(m_bus === m_r5, "sel 5 should select R5");
		m_sel = 4'd6; #1; result(m_bus === m_r6, "sel 6 should select R6");
		m_sel = 4'd7; #1; result(m_bus === m_r7, "sel 7 should select R7");
		m_sel = 4'd8; #1; result(m_bus === m_g,  "sel 8 should select G");
		m_sel = 4'd9; #1; result(m_bus === 16'hFFFB, "sel 9 should give sign-extended din (-5)");
		m_din = 9'd255;
		#1;       result(m_bus === 16'd255, "sel 9 positive din (255)");
		for (i = 10; i < 16; i = i + 1) begin
			m_sel = i; #1;
			result(m_bus === 16'd0, "unused select value should give 0");
		end
		end_component("multiplexer");

		// ---------- ALU (Student B) ----------
		begin_component("ALU");
		// multiplication
		check_alu(16'd6,      16'd7,      3'b000, 16'd42);
		check_alu(-16'sd5,    16'd3,      3'b000, -16'sd15);
		check_alu(-16'sd4,    -16'sd8,    3'b000, 16'd32);
		check_alu(16'd1234,   16'd0,      3'b000, 16'd0);
		check_alu(16'd300,    16'd300,    3'b000, 16'd24464);    // 90000 mod 65536
		// addition
		check_alu(16'd1,      16'd2,      3'b001, 16'd3);
		check_alu(16'd5,      -16'sd9,    3'b001, -16'sd4);
		check_alu(16'd32767,  16'd1,      3'b001, 16'h8000);      // overflow wraps
		// subtraction
		check_alu(16'd17,     16'd5,      3'b010, 16'd12);
		check_alu(16'd6,      16'd7,      3'b010, -16'sd1);
		check_alu(16'h8000,   16'd1,      3'b010, 16'd32767);     // underflow wraps
		// signed shift: input_b shifted by input_a
		check_alu(16'd2,      16'd3,      3'b011, 16'd12);        // left 2
		check_alu(16'd0,      16'd7,      3'b011, 16'd7);         // shift by 0
		check_alu(-16'sd3,    16'd64,     3'b011, 16'd8);         // right 3
		check_alu(-16'sd2,    -16'sd64,   3'b011, -16'sd16);      // arithmetic right keeps sign
		check_alu(16'd15,     16'd1,      3'b011, 16'h8000);      // into the sign bit
		// random vectors against the reference model
		for (i = 0; i < 200; i = i + 1) begin
			a  = $random(seed);
			b  = $random(seed);
			op = $random(seed) & 3;                   // ops 000-011
			if (op == 3'b011) a = ($random(seed) % 17); // keep shift amounts in -16..16
			check_alu(a, b, op, alu_model(a, b, op));
		end
		end_component("ALU");

		// ---------- register_n (Student B) ----------
		begin_component("register_n");
		@(negedge clk); r_rst = 1'b1;
		@(negedge clk); r_rst = 1'b0;
		result(r_q16 === 16'd0 && r_q9 === 9'd0, "reset clears both registers");
		r_d16 = 16'hA5A5; r_d9 = 9'h1AB; r_in16 = 1'b1; r_in9 = 1'b1;
		@(negedge clk);
		result(r_q16 === 16'hA5A5, "16-bit load when r_in = 1");
		result(r_q9  === 9'h1AB,   "9-bit load when r_in = 1");
		r_in16 = 1'b0; r_in9 = 1'b0; r_d16 = 16'h1234; r_d9 = 9'h055;
		@(negedge clk);
		result(r_q16 === 16'hA5A5, "16-bit holds when r_in = 0");
		result(r_q9  === 9'h1AB,   "9-bit holds when r_in = 0");
		r_in16 = 1'b1; r_rst = 1'b1;
		@(negedge clk);
		result(r_q16 === 16'd0, "reset has priority over load");
		r_rst = 1'b0;
		@(negedge clk);
		result(r_q16 === 16'h1234, "loads again after reset");
		end_component("register_n");

		// ---------- summary ----------
		$display("================================================");
		$display(" SUMMARY: %0d checks, %0d passed, %0d failed",
			pass_count + fail_count, pass_count, fail_count);
		if (fail_count == 0)
			$display(" ALL COMPONENT TESTS PASSED");
		else
			$display(" SOME TESTS FAILED - see FAIL lines above");
		$display("================================================");
		$stop;
	end

endmodule
