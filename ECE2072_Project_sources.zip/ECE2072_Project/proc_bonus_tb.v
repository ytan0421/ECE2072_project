`timescale 1ns/1ps

module proc_bonus_tb;
    reg clk;
    reg rst;
    reg enable;

    wire [8:0] din_a;
    wire [8:0] din_b;
    wire [15:0] bus_a, bus_b;
    wire [15:0] display_a, display_b;
    wire [15:0] pc_a, pc_b;
    wire [3:0] tick_a, tick_b;

    wire [15:0] tx_data_a, tx_data_b;
    wire tx_req_a, tx_req_b;
    wire rx_ack_a, rx_ack_b;

    wire [15:0] r0_a, r1_a, r2_a, r3_a, r4_a, r5_a, r6_a, r7_a;
    wire [15:0] r0_b, r1_b, r2_b, r3_b, r4_b, r5_b, r6_b, r7_b;

    // Cross connect the two processors.
    proc_bonus dut_a(
        .clk(clk), .rst(rst), .enable(enable), .din(din_a),
        .rx_data(tx_data_b), .rx_req(tx_req_b), .tx_ack(rx_ack_b),
        .tx_data(tx_data_a), .tx_req(tx_req_a), .rx_ack(rx_ack_a),
        .bus(bus_a), .display(display_a), .PC(pc_a), .tick(tick_a),
        .R0(r0_a), .R1(r1_a), .R2(r2_a), .R3(r3_a),
        .R4(r4_a), .R5(r5_a), .R6(r6_a), .R7(r7_a)
    );

    proc_bonus dut_b(
        .clk(clk), .rst(rst), .enable(enable), .din(din_b),
        .rx_data(tx_data_a), .rx_req(tx_req_a), .tx_ack(rx_ack_a),
        .tx_data(tx_data_b), .tx_req(tx_req_b), .rx_ack(rx_ack_b),
        .bus(bus_b), .display(display_b), .PC(pc_b), .tick(tick_b),
        .R0(r0_b), .R1(r1_b), .R2(r2_b), .R3(r3_b),
        .R4(r4_b), .R5(r5_b), .R6(r6_b), .R7(r7_b)
    );

    // Board A program:
    // PC0: MOVI R0, 42
    // PC2: TX R0
    // PC4: NOP/hold
    reg [8:0] mem_a [0:255];
    reg [8:0] mem_b [0:255];

    assign din_a = mem_a[pc_a[7:0]];
    assign din_b = mem_b[pc_b[7:0]];

    integer i;   // must be declared outside an unnamed block in Verilog-2001
    initial begin
        for (i = 0; i < 256; i = i + 1) begin
            mem_a[i] = 9'b000000000;
            mem_b[i] = 9'b000000000;
        end

        // MOVI R0, 42 = 111 000 000
        mem_a[0] = 9'b111000000;
        mem_a[1] = 9'b000101010;
        // TX R0 = 000 000 xxx
        mem_a[2] = 9'b000000000;

        // Board B just waits; R6 should receive 42.
        // Keep its PC at a harmless invalid instruction after reset.
        mem_b[0] = 9'b000000000;
    end

    always #5 clk = ~clk;

    initial begin
        clk = 1'b0;
        rst = 1'b1;
        enable = 1'b1;

        #20;
        rst = 1'b0;

        #500;

        $display("A R0 = %0d", $signed(r0_a));
        $display("B R6 = %0d", $signed(r6_b));
        $display("A TX_REQ = %b, B RX_ACK = %b", tx_req_a, rx_ack_b);

        if (r0_a == 16'd42 && r6_b == 16'd42)
            $display("BONUS TX/RX TEST: PASS");
        else
            $display("BONUS TX/RX TEST: FAIL");

        $finish;
    end
endmodule
